<?xml version="1.0"?>
<ProcessHandle Version="1" Minor="0">
    <Process Command=".planAhead." Owner="qazxws" Host="DESKTOP-DAF04IJ" Pid="6848">
    </Process>
</ProcessHandle>
